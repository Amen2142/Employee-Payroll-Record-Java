package PP03;
import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PayRoll {
	
	private String fileName;
	private PayRecord[] payRecordArray;
	private static int numOfRecords = 0;
	List<PayRecord> payRecords;
	private double totalNetPay;
	private double avgNetPay;
	private PayRecord payRecord ;
	private Employee employee ;
	static String message = "";
	
	public PayRoll(String fileName, int n) throws Exception
	{
		
		this.fileName = fileName;
        this.payRecords = new ArrayList<PayRecord>();
        this.payRecordArray = new PayRecord[n] ;
		readFromFile("U:\\611 Eclipse Stuff\\ZineddinPP03\\src\\PayRoll.txt");
		writeToFile();
		
	}	
	
	public void readFromFile(String fileName) throws Exception 
	{
		try {
		// Get the selected file
		java.io.File file = new java.io.File(fileName);		
		// Create a Scanner for the file
		Scanner input = new Scanner(file);
		// Read text from the file		
		List<Employee> empList = new ArrayList<Employee>();
		while (input.hasNext()) 
		{ 
			String line = input.nextLine();
			String[] stringArr = line.split(",");
			// Check to see if line starts with employee
			if(line.startsWith("employee")) {
				Status status;
				
				if(stringArr[4].trim().equalsIgnoreCase(Status.FullTime.name())) 
				{
					status = Status.FullTime;
				}
				else {
					status = Status.Hourly;
				}
				// Create Employee
				empList.add(createEmployee(stringArr[2].trim(),stringArr[3].trim(),stringArr[5].trim(), 
							Integer.parseInt(stringArr[6].trim()),stringArr[7].trim(),stringArr[8].trim(),
							Integer.parseInt(stringArr[9].trim()), Integer.parseInt(stringArr[1].trim()),status));
				//message += empList.toString()+ "\n";
			}
			
			// Check to see if line starts with payRecord
			else if(line.startsWith("payRecord"))
			{
				//connect the employee ID if they have the same ID 
				int eID = Integer.parseInt(stringArr[2].trim());
				Employee aEmployee = null;
				
				for(Employee employee: empList) 
				{
					if(eID == employee.geteID()) 
					{
						aEmployee = employee;
						break;
					}
				}
				// Assign date from file
				SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
				Date startDate = new Date();
				Date endDate = new Date();
				
				try 
				{
					startDate = aSimpleDateFormat.parse(stringArr[6].trim());
					endDate = aSimpleDateFormat.parse(stringArr[7].trim());
				}
				catch (ParseException e) 
				{
					e.printStackTrace();
				}
				
				double hours = 0;
				double rate = 0; double mIncome = 0;
				int mNum = 0;
				
				if (aEmployee.getEmpStatus() == Status.FullTime) 
				{
					mIncome = Double.parseDouble(stringArr[3].trim().replace("<m>", ""));
					mNum = Integer.parseInt(stringArr[4].trim().replace("<n>", ""));
				}
				
				else 
				{
					hours = Double.parseDouble(stringArr[3].trim().replace("<h>", ""));
					rate = Double.parseDouble(stringArr[4].trim().replace("<r>", ""));
				}
				
				this.createPayRecord(aEmployee, Integer.parseInt(stringArr[1].trim()), Integer.parseInt(stringArr[5].trim()),startDate, endDate, hours, rate, mIncome, mNum);
			}//else if
			
			
		}//while
		
		
		//Close the file
		input.close();
		System.out.println("record: " + empList.size());
		message += empList.toString() + "\n"; 
		}
	
   	
		catch (IOException e) 
		{
		e.printStackTrace();
		
		}
		//display message
		JOptionPane.showMessageDialog(null, "Completed reading data from file \"PayRoll.txt\"");
		
		
	}//readFromFile() method
	
   
   public void writeToFile() throws FileNotFoundException
   {		
		// write employees' pay records to the PayRecord.txt file, it should add employee pay record to the current file data
	   	
		java.io.File file = new java.io.File("PayRecord.txt");
		
		// create a file
		java.io.PrintWriter output = new java.io.PrintWriter(file);
		output.print(message);
		
		// close the file
		output.close();
	   
	} 
   
	public Employee createEmployee(String fName, String lName, String street, int houseNumber, String city, String state, int zipCode, int eID, Status empStatus)
	{
		// creates a new Employee object and add it to the employees array, you need to pass parameters to this method
		Employee aEmployee = new Employee(fName, lName, new Address(street, houseNumber,  city,  state, zipCode), eID, empStatus);
		return aEmployee;
		
	}	
 
	public void createPayRecord(Employee emp, int id, int pID, Date pStartDate, Date pEndDate, double hours, double rate, double mIncome, int mNum) throws FileNotFoundException
	{		
		// creates a new PayRecord for an Employee object and add it to  the payRecords array, you need to pass parameters to this method
		PayRecord p ;
		
		if(emp.getEmpStatus() == Status.FullTime) {
			p = new PayRecord(id, emp, new PayPeriod(pID, pStartDate, pEndDate), mIncome, mNum);
		} 
		
		else {
			p = new PayRecord( id, emp, new PayPeriod(pID, pStartDate, pEndDate),  hours,  rate);			
		}
		numOfRecords ++;
		totalNetPay = totalNetPay + p.netPay();
		
		System.out.println(p.toString());
		message += p.toString()+ "\n";
		writeToFile();
		
	}	
	
    public  String displayPayRecord()
    {
		// it shows all payroll records for all currently added employee and the total net pay and average net pay in the GUI text area
    	// at should append data to text area, it must not overwrite data in the GUI text area
    	String display = "";
    	
    	for(PayRecord p: payRecords)
    		display = display + p.toString() + "\r\n";  
    	
    	display = message +display + "\r\n Total NetPay: " + String.format("%.2f",this.totalNetPay) + "\r\n Average NetPay: " + String.format("%.2f",this.avgNetPay());
    	return display;
    	
	}
    
   public double avgNetPay(){		
	   	// returns the average of the total net pay of all added employees
	   	avgNetPay = totalNetPay/numOfRecords;
	   	System.out.println("size: "+numOfRecords);
	   	
	   	return avgNetPay;
		
	}
    	

}
