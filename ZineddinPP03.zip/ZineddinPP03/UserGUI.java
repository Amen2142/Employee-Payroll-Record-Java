package PP03;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class UserGUI extends JPanel {
	
	 private JLabel employee;
	 private JLabel ID;
	 private JLabel firstName;
	 private JLabel lastName;
	 private JLabel employeeStatus;
	 private JLabel employeeAddress;
	 private JLabel street;
	 private JLabel aptNumber;
	 private JLabel city;
	 private JLabel state;
	 private JLabel zipCode;
	 private JLabel payPeriod;
	 private JLabel ID2;
	 private JLabel startDate;
	 private JLabel endDate;
	 private JLabel payRecord;
	 private JLabel ID3;
	 private JLabel monthlyIncome;
	 private JLabel numberOfMonths;
	 private JLabel payHours;
	 private JLabel payRate;
	 private JLabel currentRecord;

	 
	 
	 JRadioButton fullTime;
	 JRadioButton hourly;
	 
	 
	  private JTextField fieldID;
	  private JTextField fieldID2;
	  private JTextField fieldID3;
	  private JTextField fieldFirstName;
	  private JTextField fieldLastName;
	  private JTextField fieldStreet;
	  private JTextField fieldAptNumber;
	  private JTextField fieldCity;
	  private JTextField fieldZipCode;
	  private JTextField fieldStartDate;
	  private JTextField fieldEndDate;
	  private JTextField fieldMonthlyIncome;
	  private JTextField fieldNumberOfMonth;
	  private JTextField fieldPayHour;
	  private JTextField fieldPayRate;
	  private JTextField fieldCurrentRecord;
	  
	  
	  private JButton AddEmployeeButton;
	  private JButton AddPayRecordButton;
	  private JButton CloseButton;
	  
	  ButtonGroup group;
	  
	  private JTextArea textArea;
	  
	  private JComboBox combListState;
	  
	  private JScrollPane jp;
	  
	  private PayRoll payRoll;
	  private Employee employees;
	  private PayRecord record;
	  
	  private String fileName = "PayRoll.txt";
	  
	  public UserGUI() throws Exception {
		  
                 // prompt the user to input the number of pay records
                 int n; // is the number of pay records for employees
         try {
        	          
         n = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the number of pay records: ", "Pay Records", 
        		 	JOptionPane.INFORMATION_MESSAGE));                    
                          
		 payRoll = new PayRoll(fileName,n);
		 
		 if (n <= 0)
        	 throw new Exception();
         } catch (Exception E) {
        	 JOptionPane.showMessageDialog(null, "Invalid input - Exit?", "Pay Records", JOptionPane.WARNING_MESSAGE);
        	 System.exit(0);
        	 
         }

	    initGUI();
	    doTheLayout();
	    
	    fieldPayHour.setEditable(false);
	    fieldPayRate.setEditable(false);
	    
	    //payRoll.readFromFile(fileName);
	    //payRoll.displayPayRecord();
	    textArea.setText(payRoll.displayPayRecord());

	    AddEmployeeButton.addActionListener( new java.awt.event.ActionListener() {
	        public void actionPerformed(ActionEvent e){
	            
	            if (e.getSource() == AddEmployeeButton)
	            	transfer();
	        
	        }
	    });
	    
	    AddPayRecordButton.addActionListener(new java.awt.event.ActionListener( ) {
	    	public void actionPerformed(ActionEvent e) {
	    		if (e.getSource() == AddPayRecordButton)
					try {
						addPayRecord();
					} catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					}
	    	}
	    });
	    
	    CloseButton.addActionListener( new java.awt.event.ActionListener() {
	        public void actionPerformed(ActionEvent e){
	            close();
	            }
	    });
	    
	    combListState.addActionListener( new java.awt.event.ActionListener() {
	        public void actionPerformed(ActionEvent e){
	            //transfer_actionPerformed(e);
	        	updateTextarea();
	            
	            }
	    });

	  } // end of constructor

	  private void initGUI(){
	      
		  ID = new JLabel("ID");
		  firstName = new JLabel("          First Name");
		  lastName = new JLabel("           Last Name");
		  employee = new JLabel("Employee");
		  employeeStatus = new JLabel("Employee Status");
		  employeeAddress = new JLabel("Employee Address");
		  street = new JLabel("Street");
		  aptNumber = new JLabel("          H/Apt Number");
		  city = new JLabel("               City");
		  state = new JLabel("State");
		  zipCode = new JLabel("          Zip Code");
		  ID2 = new JLabel("ID");
		  ID3 = new JLabel("ID");
		  payPeriod = new JLabel("Pay Period");
		  startDate = new JLabel("          Start Date");
		  endDate = new JLabel("         End Date");
		  payRecord = new JLabel("Pay Record");
		  monthlyIncome = new JLabel("          Monthly Income");
		  numberOfMonths = new JLabel("          Number Of Months");
		  payHours = new JLabel("Pay Hours");
		  payRate = new JLabel("          Pay Rate");
		  currentRecord = new JLabel("Current Employee Record and Stat (Total & Average Pays) ");		  
	      	      
	      fieldID = new JTextField("", 10);
	      fieldID2 = new JTextField("", 10);
	      fieldID3 = new JTextField("", 10);
	      fieldFirstName = new JTextField("",10);
	      fieldLastName = new JTextField("", 10);
	      fieldStreet = new JTextField("", 20);
	      fieldAptNumber = new JTextField("", 10);
	      fieldCity = new JTextField("", 10);
	      fieldZipCode = new JTextField("", 10);
	      fieldStartDate = new JTextField("", 15);
	      fieldEndDate = new JTextField("", 15);
	      fieldNumberOfMonth = new JTextField("", 15);
	      fieldMonthlyIncome = new JTextField("", 15);
	      fieldPayHour = new JTextField("", 15);
	      fieldPayRate = new JTextField("", 15);
	      fieldCurrentRecord = new JTextField("",30);
	      
	      fullTime = new JRadioButton("Full Time", true);
	      hourly = new JRadioButton("Hourly");
	      
	      group = new ButtonGroup();
	      group.add(fullTime);
	      group.add(hourly);
	      
	      textArea = new JTextArea(50, 50);
	      textArea.setEditable(false);
	      textArea.setLineWrap(true);
	      textArea.setWrapStyleWord(true);
	      
	      // testing
	      
	      //textArea.setText(payRoll.displayPayRecord());
	      
	      jp = new JScrollPane(textArea);
	      
	      String[] listStrings = { "","Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
	    		  					"Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
	    		  					"Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
	    		  					"New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina",
	    		  					"South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"};
	      combListState = new JComboBox(listStrings);
	      
	      AddEmployeeButton = new JButton("Add Employee");
	      AddPayRecordButton = new JButton ("Add Pay Record");
	      CloseButton = new JButton("Close");
	      
	      fieldCurrentRecord.setEditable(false);

	  }// end of creating objects method

	  private void doTheLayout(){

	      JPanel top = new JPanel();
	      JPanel top1 = new JPanel();
	      JPanel top2 = new JPanel();
	      JPanel top3 = new JPanel();
	      JPanel top4 = new JPanel();
	      JPanel top5 = new JPanel();
	      JPanel center = new JPanel();
	      JPanel center1 = new JPanel();
	      JPanel center2 = new JPanel();
	      JPanel center3 = new JPanel();
	      JPanel center4 = new JPanel();
	      JPanel bottom = new JPanel();
	      JPanel bottom1 = new JPanel();

	      JPanel bottom3 = new JPanel();

	      
	      top.setPreferredSize( new Dimension( 220, 220 ) );
	      top.setLayout( new GridLayout(7,7));
	      top.add(employee);
	      top1.add(ID);
	      top1.add(fieldID);
	      top1.add(firstName);
	      top1.add(fieldFirstName);
	      top1.add(lastName);
	      top1.add(fieldLastName);
	      
	      top2.add(employeeStatus);
	      top2.add(fullTime);
	      top2.add(hourly);
	      
	      top.add(top1, BorderLayout.CENTER);
	      top.add(top2, BorderLayout.CENTER);
	      
	      
	      top.add(employeeAddress);
	      top3.add(street);
	      top3.add(fieldStreet);
	      top3.add(aptNumber);
	      top3.add(fieldAptNumber);
	      top3.add(city);
	      top3.add(fieldCity);
	      top4.add(state);
	      top4.add(combListState);
	      top4.add(zipCode);
	      top4.add(fieldZipCode);
	      top5.add(AddEmployeeButton);
	      
	      top.add(top3, BorderLayout.CENTER);
	      top.add(top4, BorderLayout.CENTER);
	      top.add(top5, BorderLayout.CENTER);

	      center.setPreferredSize( new Dimension( 30, 30 ) );
	      center.setLayout( new GridLayout(6,6));
	      center.add(payPeriod);
	      center1.add(ID2);
	      center1.add(fieldID2);
	      center1.add(startDate);
	      center1.add(fieldStartDate);
	      center1.add(endDate);
	      center1.add(fieldEndDate);
 
	      center.add(center1, BorderLayout.CENTER);
	      
	      center.add(payRecord);
	      center2.add(ID3);
	      center2.add(fieldID3);
	      center2.add(monthlyIncome);
	      center2.add(fieldMonthlyIncome);
	      center2.add(numberOfMonths);
	      center2.add(fieldNumberOfMonth);
	      center3.add(payHours);
	      center3.add(fieldPayHour);
	      center3.add(payRate);
	      center3.add(fieldPayRate);
	      center4.add(AddPayRecordButton);
	      
	      
	      center.add(center2, BorderLayout.CENTER);
	      center.add(center3, BorderLayout.CENTER);
	      center.add(center4, BorderLayout.CENTER);
	      
	      
	      bottom.setPreferredSize(new Dimension(300,300));
	      bottom.setLayout(new GridLayout(5,5));
	      bottom.add(currentRecord);
	      bottom1.add(new JLabel(""));	     
	            
	      
	      bottom.add(bottom1, BorderLayout.NORTH);	
	     
	      bottom.add(jp);
	      bottom3.add(CloseButton);

	      bottom.add(bottom3, BorderLayout.CENTER);
	      

	      setLayout( new BorderLayout());
	      add(top, "North");
	      add(center, "Center");
	      add(bottom, "South");

	  }// end of Layout method

	 
	  void transfer(){
		   int ID = 0;
		   String firstName = "";
		   String lastName = "";
		   String employeeStatus = "";
		   String street = "";
		   int aptNum = 0;
		   String city = "";
		   String state = "";
		   int zipCode = 0;
		   

		   try {
			   
		   ID = Integer.parseInt(fieldID.getText().trim());
		   if (fieldID.getText().trim().length() != 7)
			   throw new Exception();
	
		   
		   }catch (Exception E) {
			   JOptionPane.showMessageDialog(null, "Invalid ID - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldID.setText("");
			   return;
		   } // end catch


		   try {			   
		   
		   if (fieldFirstName.getText().trim().isEmpty())
			   throw new Exception();
	
		   } catch(Exception Ex) {
			   JOptionPane.showMessageDialog(null, "Invalid First Name - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldFirstName.setText("");
			   return;
		   }

		   
		   firstName = fieldFirstName.getText().trim();
		   

		   try {			   
		   
		   if (fieldLastName.getText().trim().isEmpty())
			   throw new Exception();
	
		   } catch(Exception Ex) {
			   JOptionPane.showMessageDialog(null, "Invalid Last Name - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldLastName.setText("");
			   return;
		   }

		   
		   lastName = fieldLastName.getText().trim();
			

		   try {			   
		   
		   if (fieldStreet.getText().trim().isEmpty())
			   throw new Exception();
	
		   } catch(Exception Ex) {
			   JOptionPane.showMessageDialog(null, "Invalid Street - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldStreet.setText("");
			   return;
		   }

		   
		   street = fieldStreet.getText().trim();
		   
		   aptNum = Integer.parseInt(fieldAptNumber.getText().trim());

		   try {			   
		   
		   if (fieldCity.getText().trim().isEmpty())
			   throw new Exception();

		   } catch(Exception Ex) {
			   JOptionPane.showMessageDialog(null, "Invalid City - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldCity.setText("");
			   return;
		   }

		   
		   city = fieldCity.getText().trim();
		   
		   

		   try {
			   zipCode = Integer.parseInt(fieldZipCode.getText().trim());
		   if (fieldZipCode.getText().trim().length() != 5)
			   throw new Exception();

		   
		   }catch (Exception ExC) {
			   JOptionPane.showMessageDialog(null, "Invalid Zip Code - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldZipCode.setText("");
			   return;
		   } // end catch

		   state = combListState.getSelectedItem().toString();	  
				   
		   if (hourly.isSelected()) {
			   employees = new Employee(firstName, lastName, new Address(street, aptNum, city, state, zipCode), ID, Status.Hourly);
			   employeeStatus = "Hourly";
		   }
		   else if (fullTime.isSelected()) {
			   employees = new Employee(firstName, lastName, new Address(street, aptNum, city, state, zipCode), ID, Status.FullTime);
			   employeeStatus = "Full Time";
		   }

		    
			   
		  
	        String mytext = "ID: " + fieldID.getText() + "\t\tName: " + fieldFirstName.getText() + " " + fieldLastName.getText() + "\t\tEmployee Status: "
	        		+ employeeStatus + "\nStreet: " + fieldStreet.getText() + "\t\tApt Number: " + fieldAptNumber.getText() + "\t\tCity: " 
	        		+ fieldCity.getText() + "\nState: " + state + "\t\tZip Code: " + zipCode;
	        
	        
	        textArea.setText(mytext);
	        
		    fieldPayHour.setEditable(true);
		    fieldPayRate.setEditable(true);
	        
	        
	  }// end of transfer action event method
	  
	  void addPayRecord() throws FileNotFoundException {
		  
		  int ID2 = 0;
		  int ID3 = 0;
		  double monthlyIncome = 0;
		  int numberOfMonths = 0;
		  double payHour = 0;
		  double payRate = 0;
		  

		   try {
			   
		   ID2 = Integer.parseInt(fieldID2.getText().trim());
		   if (fieldID2.getText().trim().length() != 7)
			   throw new Exception();
		   
		   }catch (Exception E) {
			   JOptionPane.showMessageDialog(null, "Invalid ID - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldID2.setText("");
			   return;
		   } // end catch

		   
		   
		   	Date start = null;
			Date end = null;
			DateFormat date = new SimpleDateFormat("MM/dd/yyyy");
			date.setLenient(false);
		   
		   try {			   
			   start = date.parse(fieldStartDate.getText());
			   
		   } catch(ParseException E) {
			   JOptionPane.showMessageDialog(null, "Invalid Start date - please enter as format MM/DD/YYYY !", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldStartDate.setText("");
			   return;
		   }


		   try {			   
		   
			   end = date.parse(fieldEndDate.getText());

		   } catch(Exception Ex) {
			   JOptionPane.showMessageDialog(null, "Invalid End date - please enter as format MM/DD/YYYY !", "Warning", JOptionPane.WARNING_MESSAGE );
			   fieldEndDate.setText("");
			   return;
		   }
		   	
		   if (end.before(start)) {
			   JOptionPane.showMessageDialog(null, "Invalid End date - please enter as format MM/DD/YYYY !", "Warning", JOptionPane.WARNING_MESSAGE );
		   		fieldEndDate.setText("");
		   		return;
		   }
		   		 
		   

			   try {
				   
			   ID3 = Integer.parseInt(fieldID3.getText().trim());
			   if (fieldID3.getText().trim().length() != 7)
				   throw new Exception();

			   
			   }catch (Exception E) {
				   JOptionPane.showMessageDialog(null, "Invalid ID - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
				   fieldID3.setText("");
				   return;
			   } // end catch


			   try {
			   monthlyIncome = Integer.parseInt(fieldMonthlyIncome.getText().trim());
			   if (fieldMonthlyIncome.getText().trim().isEmpty())
				   throw new Exception();

			   
			   }catch (Exception E) {
				   JOptionPane.showMessageDialog(null, "Invalid Monthyly Income - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
				   fieldMonthlyIncome.setText("");
				   return;
			   } // end catch			 		
			   			  
			   try { 
				   
				   LocalDate d1 = LocalDate.of(start.getYear(), start.getMonth(), start.getDay());
				   LocalDate d2 = LocalDate.of(end.getYear(), end.getMonth(), end.getDay());		   
				   
				   Period d = Period.between(d1, d2);
				   				   
				   int month = d.getMonths();
				   int year = d.getYears();
				   int days = d.getDays();
				   int numMonth = 0;
				   
				if (year == 0)   {
				  numMonth = month;
				}
				else {
				numMonth = (year * 12) + month;
				}
					   
			   numberOfMonths = Integer.parseInt(fieldNumberOfMonth.getText().trim());
			   if ((numberOfMonths > numMonth) || (fieldNumberOfMonth.getText().trim().isEmpty()))
				   throw new Exception();
	
			   
			   }catch (Exception E) {
				   JOptionPane.showMessageDialog(null, "Invalid Number Of Months - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
				   fieldNumberOfMonth.setText("");
				   return;
			   } // end catch

			   try {
				   payHour = Integer.parseInt(fieldPayHour.getText().trim());
				   if (fieldPayHour.getText().trim().isEmpty())
					   throw new Exception();

				   
				   }catch (Exception E) {
					   JOptionPane.showMessageDialog(null, "Invalid Pay Hour - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
					   fieldPayHour.setText("");
					   return;
				   } // end catch
			   
			   try {
				   payRate = Integer.parseInt(fieldPayRate.getText().trim());
				   if (fieldPayRate.getText().trim().isEmpty())
					   throw new Exception();

				   
				   }catch (Exception E) {
					   JOptionPane.showMessageDialog(null, "Invalid Pay Rate - please enter again!", "Warning", JOptionPane.WARNING_MESSAGE );
					   fieldPayRate.setText("");
					   return;
				   } // end catch
			   
		if (hourly.isSelected()) {
			   record = new PayRecord(ID3, employees, new PayPeriod(ID2, start, end), payHour,  payRate);
			
		}
		else if (fullTime.isSelected()) {
			 record = new PayRecord(ID3, employees, new PayPeriod(ID2, start, end), monthlyIncome,  numberOfMonths);
		}
		
		   payRoll.createPayRecord(employees, ID2, ID3, start, end, payHour, payRate, monthlyIncome, numberOfMonths);
		   
			  String mytext = record.toString();
			   
			   textArea.setText(mytext);
		  
	  } // end addPayRecord()
	  
	  void updateTextarea(){
		  
		  textArea.setText("You have selected " + combListState.getSelectedItem());
		 
	  }

	  void close(){
	      System.exit(0);
	  }// end of transfer action event method


	public static void main(String[] args) throws Exception {
	   JFrame f = new JFrame("Pay Roll");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container contentPane = f.getContentPane();
        contentPane.add( new UserGUI());
        //f.pack();
        f.setSize(800, 1000);        
        f.setVisible(true);

	}

}
