package PP03;

public class TaxIncome implements Taxable
{

	// Default constructor
	public TaxIncome()
	{
		
	}
	
	@Override
	public double compStateTax(double grossPay) 
	{
		return grossPay * STATE_TAX;
	}

	@Override
	public double compFederalTax(double grossPay) 
	{
		return grossPay * FEDERAL_TAX;
	}

	@Override
	public double compIncomeTax(double grossPay) 
	{
		return compStateTax(grossPay) + compFederalTax(grossPay); 
	}
	
}
